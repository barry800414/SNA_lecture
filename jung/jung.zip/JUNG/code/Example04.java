import edu.uci.ics.jung.graph.*;
import org.apache.commons.collections15.*;
import edu.uci.ics.jung.algorithms.scoring.*;
import java.util.Random;

public class Example04{
	public static void main(String[] argv){
		// Constructs a star graph where edges weights are randomly given from [0, 10000)
		UndirectedGraph<Integer, Edge> g = new UndirectedSparseGraph<Integer, Edge>();
		Random random = new Random();
		
		g.addVertex(0);
		for(int v = 1; v <= 5; v ++){
			g.addVertex(v);
			g.addEdge(new Edge(v, random.nextInt(10000)), 0, v);
		}
		
		Transformer<Edge, Double> transformer = new Transformer<Edge, Double>(){
			public Double transform(Edge e){
				return e.weight;
			}
		};
		
		ClosenessCentrality<Integer, Edge> cc = new ClosenessCentrality<Integer, Edge>(g, transformer);
		
		for(int v: g.getVertices()){
			System.out.printf("Vertex: %d\tCC: %f\n", v, cc.getVertexScore(v));
		}
	}
}

class Edge{
	public int id;
	public double weight;
	public Edge(int id, double weight){
		this.id = id;
		this.weight = weight;
	}
}