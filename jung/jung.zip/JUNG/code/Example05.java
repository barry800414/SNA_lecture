import edu.uci.ics.jung.graph.*;
import org.apache.commons.collections15.*;
import edu.uci.ics.jung.algorithms.generators.random.*;
import java.util.*;

public class Example05{
	public static void main(String[] argv){
		// Graph factory
		Factory< Graph<Integer, Integer> > gf = new Factory< Graph<Integer, Integer> >(){
			public Graph<Integer, Integer> create(){
				return new UndirectedSparseGraph<Integer, Integer>();
			}
		};
		
		// Vertex factory
		Factory< Integer > vf = new Factory< Integer >(){
			private int counter = 0;
			public Integer create(){
				return new Integer(counter ++);
			}
		};
		
		// Edge factory
		Factory< Integer > ef = new Factory< Integer >(){
			private int counter = 0;
			public Integer create(){
				return new Integer(counter ++);
			}
		};
		
		// Creates an artificial graph by BA model
		Set<Integer> seedVertices = new HashSet<Integer>();
		BarabasiAlbertGenerator<Integer, Integer> ba = new BarabasiAlbertGenerator<Integer, Integer> (gf, vf, ef, 4, 3, 0, seedVertices);
		ba.evolveGraph(10);
		Graph<Integer, Integer> g = ba.create();
		System.out.println(g);
	}
}