import edu.uci.ics.jung.graph.*;


public class Example03{
	public static void main(String[] argv){
		UndirectedGraph<Vertex, Edge> g = new UndirectedSparseGraph<Vertex, Edge>();
		
		Vertex zero = new Vertex(0, "zero", 3.14);
		Vertex one = new Vertex(1, "one", 2.72);
		g.addVertex(zero);
		g.addVertex(one);
		g.addEdge(new Edge(0, "zero-one", 22.46), zero, one);
		
		System.out.println("Vertex:");
		for(Vertex v: g.getVertices()){
			System.out.printf("\t%d\t%s\t%f\n", v.id, v.name, v.weight);
		}
		
		System.out.println("Edge:");
		for(Edge e: g.getEdges()){
			System.out.printf("\t%d\t%s\t%f\n", e.id, e.name, e.weight);
		}
	}
}

class Vertex{
	public int id;
	public String name;
	public double weight;
	public Vertex(int id, String name, double weight){
		this.id = id;
		this.name = name;
		this.weight = weight;
	}
}

class Edge{
	public int id;
	public String name;
	public double weight;
	public Edge(int id, String name, double weight){
		this.id = id;
		this.name = name;
		this.weight = weight;
	}
}