import edu.uci.ics.jung.graph.*;
import edu.uci.ics.jung.visualization.*;
import org.apache.commons.collections15.*;
import edu.uci.ics.jung.algorithms.layout.*;
import javax.swing.*;
import java.awt.*;

public class Example06{
	public static void main(String[] argv){
		// Constructs a complete graph
		UndirectedGraph<Integer, Integer> g = new UndirectedSparseGraph<Integer, Integer>();
		int vertexCount = 12;
		int edgeCounter = 0;
		for(int v = 0; v < vertexCount; v ++){
			g.addVertex(v);
			for(int u = v + 1; u < vertexCount; u ++){
				g.addVertex(u);
				g.addEdge(edgeCounter ++, v, u);
			}
		}
		
		Layout<Integer, Integer> layout = new CircleLayout<Integer, Integer>(g);
		layout.setSize(new Dimension(800, 800));
		BasicVisualizationServer<Integer, Integer> vv = new BasicVisualizationServer<Integer, Integer>(layout);
		vv.setPreferredSize(new Dimension(800, 800));
		
		JFrame frame = new JFrame("Graph");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().add(vv);
		frame.pack();
		frame.setVisible(true);
	}
}