import edu.uci.ics.jung.graph.*;

public class Example01{
	public static void main(String[] argv){
		DirectedGraph<Integer, Integer> g = new DirectedSparseGraph<Integer, Integer>();
		
		for(int v = 0; v <= 4; v ++){
			g.addVertex(v);
		}
		
		for(int v = 0; v <= 3; v ++){
			int e = v + 5;
			g.addEdge(e, v, v + 1);
		}
		
		System.out.println(g);
	}
}
