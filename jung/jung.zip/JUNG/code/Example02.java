import edu.uci.ics.jung.graph.*;

public class Example02{
	public static void main(String[] argv){
		DirectedGraph<Integer, Integer> g = new DirectedSparseGraph<Integer, Integer>();
		
		for(int v = 0; v <= 4; v ++){
			g.addVertex(v);
		}
		
		for(int v = 0; v <= 3; v ++){
			int e = v + 5;
			g.addEdge(e, v, v + 1);
		}
		
		for(int v: g.getVertices()){
			System.out.printf("Vertex %d\n", v);
			System.out.printf("Neighbor count: %d\n", g.getNeighborCount(v));
			System.out.printf("Out-degree %d\n", g.outDegree(v));
			
			for(int x: g.getSuccessors(v)){
				System.out.printf("\tNeighbor %d\n", x);
			}
			System.out.println();
		}
	}
}
