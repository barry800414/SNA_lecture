範例展示：
執行 script\Example[01 - 06].bat 。

資料夾：
jung：JUNG 工具
code：範例程式碼，Example[01-06].java
script：範例程式碼之執行腳本，Example[01-06].bat